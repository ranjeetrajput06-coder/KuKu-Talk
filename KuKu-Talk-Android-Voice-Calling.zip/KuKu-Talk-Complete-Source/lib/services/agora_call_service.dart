import 'dart:convert';
import 'dart:math';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:http/http.dart' as http;

class AgoraCallCredentials {
  const AgoraCallCredentials({required this.appId, required this.token, required this.uid});
  final String appId;
  final String token;
  final int uid;
}

/// Gets short-lived RTC credentials from the owner's backend. The App
/// Certificate must never be placed in this app.
class AgoraCallService {
  RtcEngine? _engine;
  bool _joined = false;
  bool _muted = false;
  bool _speaker = true;

  bool get isJoined => _joined;
  bool get isMuted => _muted;
  bool get isSpeakerOn => _speaker;

  Future<AgoraCallCredentials> fetchCredentials({
    required String backendUrl,
    required String channel,
  }) async {
    final base = backendUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (!(base.startsWith('https://') || base.startsWith('http://'))) {
      throw const FormatException('Backend URL must start with https:// or http://');
    }
    final uid = Random.secure().nextInt(2000000000) + 1;
    final uri = Uri.parse('$base/agora/token');
    final response = await http
        .post(uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'channelName': channel, 'uid': uid}))
        .timeout(const Duration(seconds: 20));
    Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw Exception('Token server returned an invalid response (${response.statusCode}).');
    }
    if (response.statusCode != 200) {
      throw Exception(data['error']?.toString() ?? 'Token request failed (${response.statusCode}).');
    }
    final appId = data['appId']?.toString() ?? '';
    final token = data['token']?.toString() ?? '';
    if (appId.isEmpty || token.isEmpty) {
      throw Exception('Token server response is missing appId or token.');
    }
    return AgoraCallCredentials(appId: appId, token: token, uid: uid);
  }

  Future<void> connect({
    required AgoraCallCredentials credentials,
    required String channel,
    required void Function(String) onStatus,
    required void Function(bool) onJoinChanged,
  }) async {
    await dispose();
    final engine = createAgoraRtcEngine();
    _engine = engine;
    await engine.initialize(RtcEngineContext(appId: credentials.appId));
    await engine.enableAudio();
    await engine.setAudioScenario(AudioScenarioType.audioScenarioChatRoom);
    engine.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (connection, elapsed) {
        _joined = true;
        onJoinChanged(true);
        onStatus('Connected. You can speak now.');
      },
      onUserJoined: (connection, uid, elapsed) => onStatus('Other learner joined. UID: $uid'),
      onUserOffline: (connection, uid, reason) => onStatus('Other learner left the call.'),
      onLeaveChannel: (connection, stats) {
        _joined = false;
        onJoinChanged(false);
        onStatus('Call ended.');
      },
      onError: (code, message) => onStatus('Agora error ($code): $message'),
      onConnectionStateChanged: (connection, state, reason) {
        onStatus('Connection: ${state.name}');
      },
    ));
    await engine.joinChannel(
      token: credentials.token,
      channelId: channel,
      uid: credentials.uid,
      options: const ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileCommunication,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: true,
        autoSubscribeAudio: true,
      ),
    );
  }

  Future<void> toggleMute() async {
    final engine = _engine;
    if (engine == null) return;
    _muted = !_muted;
    await engine.muteLocalAudioStream(_muted);
  }

  Future<void> toggleSpeaker() async {
    final engine = _engine;
    if (engine == null) return;
    _speaker = !_speaker;
    await engine.setEnableSpeakerphone(_speaker);
  }

  Future<void> leave() async {
    final engine = _engine;
    if (engine != null && _joined) await engine.leaveChannel();
    _joined = false;
    _muted = false;
    _speaker = true;
  }

  Future<void> dispose() async {
    final engine = _engine;
    if (engine != null) {
      if (_joined) await engine.leaveChannel();
      await engine.release();
    }
    _engine = null;
    _joined = false;
    _muted = false;
    _speaker = true;
  }
}
