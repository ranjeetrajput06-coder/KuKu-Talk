import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/agora_call_service.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final backendController = TextEditingController(
    text: const String.fromEnvironment('TOKEN_SERVER_URL'),
  );
  final channelController = TextEditingController(text: 'kuku-practice-room');
  final service = AgoraCallService();
  String status = 'Ready to connect';
  bool joined = false;
  bool busy = false;
  bool muted = false;
  bool speaker = true;

  Future<void> startCall() async {
    final channel = channelController.text.trim();
    final backend = backendController.text.trim();
    if (channel.isEmpty) return _showStatus('Please enter a channel name.');
    if (!RegExp(r'^[a-zA-Z0-9_-]{1,64}$').hasMatch(channel)) {
      return _showStatus('Channel: use 1–64 letters, numbers, _ or -.');
    }
    if (backend.isEmpty) return _showStatus('Enter your deployed token server URL.');
    setState(() { busy = true; status = 'Requesting secure call token...'; });
    try {
      final permission = await Permission.microphone.request();
      if (!permission.isGranted) throw Exception('Microphone permission is required.');
      final credentials = await service.fetchCredentials(backendUrl: backend, channel: channel);
      if (!mounted) return;
      setState(() => status = 'Connecting to voice room...');
      await service.connect(
        credentials: credentials,
        channel: channel,
        onStatus: (value) { if (mounted) setState(() => status = value); },
        onJoinChanged: (value) { if (mounted) setState(() => joined = value); },
      );
    } catch (error) {
      if (mounted) _showStatus(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _showStatus(String value) {
    if (mounted) setState(() => status = value);
  }

  Future<void> endCall() async {
    setState(() => busy = true);
    try {
      await service.leave();
      if (mounted) setState(() { joined = false; muted = false; speaker = true; status = 'Call ended.'; });
    } catch (error) {
      _showStatus(error.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> toggleMute() async {
    try { await service.toggleMute(); if (mounted) setState(() => muted = service.isMuted); }
    catch (error) { _showStatus(error.toString()); }
  }

  Future<void> toggleSpeaker() async {
    try { await service.toggleSpeaker(); if (mounted) setState(() => speaker = service.isSpeakerOn); }
    catch (error) { _showStatus(error.toString()); }
  }

  @override
  void dispose() {
    backendController.dispose();
    channelController.dispose();
    service.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('KuKu Voice Call')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 12),
      CircleAvatar(radius: 48, backgroundColor: joined ? Colors.green.shade100 : const Color(0xFFEAE3FF),
        child: Icon(joined ? Icons.graphic_eq : Icons.call, size: 48,
          color: joined ? Colors.green.shade800 : const Color(0xFF5B35B5))),
      const SizedBox(height: 18),
      Text(status, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 24),
      TextField(controller: backendController, enabled: !joined && !busy,
        keyboardType: TextInputType.url,
        decoration: const InputDecoration(labelText: 'Token server URL', hintText: 'https://your-server.example.com', border: OutlineInputBorder(), prefixIcon: Icon(Icons.cloud_outlined))),
      const SizedBox(height: 14),
      TextField(controller: channelController, enabled: !joined && !busy,
        decoration: const InputDecoration(labelText: 'Practice room / channel name', border: OutlineInputBorder(), prefixIcon: Icon(Icons.meeting_room_outlined))),
      const SizedBox(height: 18),
      if (!joined) FilledButton.icon(
        onPressed: busy ? null : startCall,
        icon: const Icon(Icons.call), label: Text(busy ? 'Please wait...' : 'Start Voice Call'),
      ) else ...[
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: busy ? null : toggleMute,
            icon: Icon(muted ? Icons.mic_off : Icons.mic), label: Text(muted ? 'Unmute' : 'Mute'))),
          const SizedBox(width: 12),
          Expanded(child: OutlinedButton.icon(onPressed: busy ? null : toggleSpeaker,
            icon: Icon(speaker ? Icons.volume_up : Icons.hearing), label: Text(speaker ? 'Speaker on' : 'Speaker off'))),
        ]),
        const SizedBox(height: 14),
        FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.red),
          onPressed: busy ? null : endCall, icon: const Icon(Icons.call_end), label: const Text('End Call')),
      ],
      const SizedBox(height: 20),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('How to connect two phones', style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('1. Deploy the KuKu token backend and enter its HTTPS URL on both phones.\n2. Enter exactly the same channel name on both phones.\n3. Tap Start Voice Call on each phone. Each phone receives its own short-lived token.'),
      ]))),
      const SizedBox(height: 8),
      const Text('Keep your Agora App Certificate only on the backend. Never paste it into this app.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );
}
