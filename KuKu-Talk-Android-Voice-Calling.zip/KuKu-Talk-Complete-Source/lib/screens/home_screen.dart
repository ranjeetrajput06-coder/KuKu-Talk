import 'package:flutter/material.dart';
import 'call_screen.dart';
import 'course_screen.dart';
import 'account_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('KuKu Talk')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6844C5), Color(0xFF9878E8)]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.record_voice_over, color: Colors.white, size: 44),
            SizedBox(height: 14),
            Text('Speak English with confidence!',
              style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Learn • Practise • Connect', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 20),
        _Tile(icon: Icons.menu_book, title: 'Learn English',
          subtitle: 'Spoken English, grammar and vocabulary',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CourseScreen()))),
        _Tile(icon: Icons.call, title: 'Voice Calling',
          subtitle: 'Practise speaking with another learner',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CallScreen()))),
        _Tile(icon: Icons.person, title: 'Account & Membership',
          subtitle: 'Sign-in and subscription setup',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountScreen()))),
        const SizedBox(height: 10),
        const Card(child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('Hindi + English  |  Students + Adults',
            textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600)),
        )),
      ],
    ),
  );
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon; final String title; final String subtitle; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(
      leading: CircleAvatar(child: Icon(icon)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle), trailing: const Icon(Icons.arrow_forward_ios, size: 16), onTap: onTap,
    ),
  );
}
