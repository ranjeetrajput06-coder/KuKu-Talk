import 'package:flutter/material.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Account & Membership')),
    body: ListView(padding: const EdgeInsets.all(20), children: const [
      Icon(Icons.account_circle, size: 76, color: Color(0xFF5B35B5)),
      SizedBox(height: 14),
      Text('Authentication and payments setup',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 14),
      Card(child: Padding(padding: EdgeInsets.all(16), child: Text(
        'This source package includes the app screens and setup instructions. '
        'Phone OTP and Google sign-in require your Firebase project configuration. '
        'Premium payments require a merchant account and a verified payment backend.',
        textAlign: TextAlign.center,
      ))),
      SizedBox(height: 12),
      ListTile(leading: Icon(Icons.phone_android), title: Text('Mobile OTP'), subtitle: Text('Firebase Authentication setup required')),
      ListTile(leading: Icon(Icons.g_mobiledata), title: Text('Google Login'), subtitle: Text('Firebase + Google provider setup required')),
      ListTile(leading: Icon(Icons.workspace_premium), title: Text('Premium Membership'), subtitle: Text('Payment gateway credentials and server verification required')),
    ]),
  );
}
