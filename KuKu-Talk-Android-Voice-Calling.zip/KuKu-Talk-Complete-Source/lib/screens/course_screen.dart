import 'package:flutter/material.dart';

class CourseScreen extends StatelessWidget {
  const CourseScreen({super.key});
  static const courses = <({String title, String detail, IconData icon})>[
    (title: 'Basic English', detail: 'Greetings, introductions and everyday sentences', icon: Icons.waving_hand),
    (title: 'Spoken English', detail: 'Daily conversation and speaking practice', icon: Icons.record_voice_over),
    (title: 'Grammar', detail: 'Tenses, articles and sentence structure', icon: Icons.edit_note),
    (title: 'Vocabulary', detail: 'Useful words with Hindi meanings', icon: Icons.abc),
    (title: 'Pronunciation', detail: 'Sounds, stress and clear speaking', icon: Icons.hearing),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('English Courses')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      for (final course in courses)
        Card(child: ListTile(
          leading: Icon(course.icon, size: 30, color: Theme.of(context).colorScheme.primary),
          title: Text(course.title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(course.detail),
          onTap: () => showDialog<void>(context: context, builder: (_) => AlertDialog(
            title: Text(course.title),
            content: Text('${course.detail}.\n\nAdd lesson videos, audio and exercises in the course content module.'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
          )),
        )),
    ]),
  );
}
