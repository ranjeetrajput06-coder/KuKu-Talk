import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KuKuTalkApp());
}

class KuKuTalkApp extends StatelessWidget {
  const KuKuTalkApp({super.key});

  @override
  Widget build(BuildContext context) {
    const brand = Color(0xFF5B35B5);
    return MaterialApp(
      title: 'KuKu Talk',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brand),
        scaffoldBackgroundColor: const Color(0xFFF8F6FF),
        appBarTheme: const AppBarTheme(
          backgroundColor: brand, foregroundColor: Colors.white, centerTitle: true,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
