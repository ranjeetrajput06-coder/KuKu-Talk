import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { RtcTokenBuilder, RtcRole } from 'agora-token';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '8kb' }));

const appId = process.env.AGORA_APP_ID?.trim();
const certificate = process.env.AGORA_APP_CERTIFICATE?.trim();
const ttl = Math.min(3600, Math.max(300, Number(process.env.TOKEN_TTL_SECONDS || 1800)));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'kuku-talk-token-service' }));

app.post('/agora/token', (req, res) => {
  if (!appId || !certificate) {
    return res.status(503).json({ error: 'Agora server credentials are not configured.' });
  }
  const channelName = String(req.body?.channelName || '').trim();
  const uid = Number(req.body?.uid);
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(channelName)) {
    return res.status(400).json({ error: 'Invalid channelName. Use 1–64 letters, numbers, _ or -.' });
  }
  if (!Number.isSafeInteger(uid) || uid < 1 || uid > 2147483647) {
    return res.status(400).json({ error: 'Invalid uid. A positive 32-bit integer is required.' });
  }
  try {
    const expiresAt = Math.floor(Date.now() / 1000) + ttl;
    const token = RtcTokenBuilder.buildTokenWithUid(
      appId, certificate, channelName, uid, RtcRole.PUBLISHER, expiresAt, expiresAt,
    );
    return res.json({ appId, channelName, uid, token, expiresAt });
  } catch (error) {
    console.error('Agora token generation failed:', error);
    return res.status(500).json({ error: 'Unable to generate Agora token.' });
  }
});

const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => process.stdout.write(`KuKu Talk token service listening on ${port}\n`));
