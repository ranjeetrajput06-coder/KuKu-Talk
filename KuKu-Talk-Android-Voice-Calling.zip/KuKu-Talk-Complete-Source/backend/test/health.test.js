import test from 'node:test';
import assert from 'node:assert/strict';

test('health endpoint contract', () => {
  const payload = { ok: true, service: 'kuku-talk-token-service' };
  assert.equal(payload.ok, true);
  assert.equal(payload.service, 'kuku-talk-token-service');
});
