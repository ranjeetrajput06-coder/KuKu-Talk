import 'package:flutter_test/flutter_test.dart';
import 'package:kuku_talk/main.dart';

void main() {
  testWidgets('KuKu Talk home screen renders', (tester) async {
    await tester.pumpWidget(const KuKuTalkApp());
    expect(find.text('KuKu Talk'), findsOneWidget);
    expect(find.text('Voice Calling'), findsOneWidget);
    expect(find.text('Learn English'), findsOneWidget);
  });
}
