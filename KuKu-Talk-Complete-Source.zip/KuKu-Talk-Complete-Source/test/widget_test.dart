import 'package:flutter_test/flutter_test.dart';
import 'package:kuku_talk/main.dart';

void main() {
  testWidgets('home screen renders main actions', (tester) async {
    await tester.pumpWidget(const KuKuTalkApp());
    expect(find.text('KuKu Talk'), findsOneWidget);
    expect(find.text('Speak English with confidence!'), findsOneWidget);
    expect(find.text('Voice Calling'), findsOneWidget);
  });
}
