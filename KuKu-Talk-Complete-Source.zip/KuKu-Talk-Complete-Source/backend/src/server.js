import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { RtcTokenBuilder, RtcRole } from 'agora-token';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '16kb' }));

const appId = process.env.AGORA_APP_ID;
const certificate = process.env.AGORA_APP_CERTIFICATE;
const ttl = Math.max(300, Number(process.env.TOKEN_TTL_SECONDS || 3600));

app.get('/health', (_req, res) => res.json({ ok: true, service: 'kuku-talk-token-service' }));

app.post('/agora/token', (req, res) => {
  if (!appId || !certificate) return res.status(503).json({ error: 'Agora server credentials are not configured.' });
  const channelName = String(req.body?.channelName || '').trim();
  const uid = Number(req.body?.uid || 0);
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(channelName)) return res.status(400).json({ error: 'Invalid channelName.' });
  if (!Number.isInteger(uid) || uid < 0 || uid > 4294967295) return res.status(400).json({ error: 'Invalid uid.' });
  const now = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = now + ttl;
  const token = RtcTokenBuilder.buildTokenWithUid(
    appId, certificate, channelName, uid, RtcRole.PUBLISHER, privilegeExpiredTs, privilegeExpiredTs
  );
  res.json({ appId, channelName, uid, token, expiresAt: privilegeExpiredTs });
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => process.stdout.write(`KuKu Talk token service listening on ${port}\n`));
