# KuKu Talk — Setup Guide (Hindi)

## Is ZIP mein kya hai
- Flutter app source: Home, English course menu, Account/Membership information, Voice Call screen.
- Agora RTC calling client code.
- Node.js backend source for issuing short-lived Agora RTC tokens.
- Android Gradle/Kotlin app scaffold.

## Zaroori sach
Yeh **complete source-code starter package** hai, ready-to-publish finished product nahi. Hum aapke Firebase, Agora, payment merchant accounts ya signing keys khud se nahi bana sakte. Is environment mein Flutter/Android SDK installed nahi hai, isliye APK build aur device testing nahi ki gayi. iOS native project folder bhi Flutter tool se generate karna hoga (Mac + Xcode required).

## Android par run (computer par)
1. ZIP extract karein.
2. Flutter SDK, Android Studio aur Android SDK install karein.
3. Project folder ke terminal mein:
   - `flutter create --platforms=android,ios .` (yeh missing generated platform files create karega; iOS ke liye macOS chahiye)
   - `flutter pub get`
   - `flutter analyze`
   - `flutter test`
   - `flutter run`

## Agora voice calling setup
1. Agora Console mein project banayein.
2. Backend folder mein `.env.example` ko `.env` naam se copy karein.
3. `.env` mein App ID aur App Certificate set karein. Certificate sirf backend par rahe; app ke andar kabhi nahi.
4. Backend mein `npm install` aur `npm start` chalayein.
5. Mobile app ko backend `/agora/token` se token lene ke liye configure karein. Abhi call screen development placeholder token dikhata hai; production token fetching wiring aur user authentication/authorization backend endpoint se jodni hogi.
6. Dono devices par same channel aur alag valid UIDs/tokens ke saath test karein.

## Firebase OTP / Google login
1. Firebase Console mein project banayein.
2. Android package ID `com.kuku.talk` add karein.
3. Firebase Authentication mein Phone aur Google providers enable karein.
4. FlutterFire CLI se `flutterfire configure` karein aur `firebase_options.dart` generate karein.
5. `firebase_auth`, `firebase_core`, `google_sign_in` packages add karke auth flow implement aur test karein. Is ZIP mein sign-in UI/instructions hain, active Firebase login nahi.

## Premium payments
Payment provider (Razorpay/Stripe etc.) merchant onboarding, API keys, webhook verification aur server-side subscription entitlement checks ke bina premium payment activate nahi ho sakta. Never trust a payment success flag sent only by the mobile app. Select provider and complete merchant KYC first.

## iPhone
iOS native folder Xcode/Flutter tooling se generate aur configure karna hoga. iOS build ke liye Mac with Xcode, Apple Developer signing and Agora/Firebase iOS configuration required.
