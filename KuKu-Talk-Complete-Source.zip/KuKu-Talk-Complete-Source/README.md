# KuKu Talk — Complete Source Code Starter

This repository contains Flutter app source, Android scaffold, and a Node.js Agora token-service starter. See `docs/SETUP_HINDI.md` before running.

**Not production-ready yet:** Firebase OTP/Google authentication is not wired; payment gateway is not implemented; Agora token endpoint is not yet connected from the mobile screen; iOS native project must be generated with Flutter on macOS; no APK/IPA has been built or device-tested. Real credentials and merchant accounts must be supplied by the app owner.
