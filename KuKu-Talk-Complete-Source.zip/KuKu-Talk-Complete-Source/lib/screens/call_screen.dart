import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/agora_call_service.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  // Replace with your Agora App ID. Do not add App Certificate in this app.
  static const agoraAppId = 'YOUR_AGORA_APP_ID';
  // Paste a short-lived token for development only; production should fetch from backend.
  static const developmentToken = 'YOUR_TEMPORARY_RTC_TOKEN';
  final channelController = TextEditingController(text: 'kuku-practice-room');
  final service = AgoraCallService();
  String status = 'Not connected';
  bool joined = false;
  bool busy = false;

  Future<void> startCall() async {
    final channel = channelController.text.trim();
    if (channel.isEmpty) { setState(() => status = 'Enter a channel name.'); return; }
    if (developmentToken == 'YOUR_TEMPORARY_RTC_TOKEN') {
      setState(() => status = 'Set Agora temporary token or connect the secure token backend.');
      return;
    }
    setState(() { busy = true; status = 'Checking microphone permission...'; });
    try {
      final permission = await Permission.microphone.request();
      if (!permission.isGranted) throw StateError('Microphone permission denied.');
      await service.initialize(appId: agoraAppId,
        onStatus: (s) { if (mounted) setState(() => status = s); },
        onJoinChanged: (v) { if (mounted) setState(() => joined = v); });
      await service.join(channel: channel, token: developmentToken);
    } catch (e) {
      if (mounted) setState(() => status = e.toString().replaceFirst('Bad state: ', ''));
    } finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> endCall() async {
    setState(() => busy = true);
    try { await service.leave(); }
    catch (e) { if (mounted) setState(() => status = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  void dispose() { channelController.dispose(); service.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('KuKu Voice Call')),
    body: Padding(padding: const EdgeInsets.all(22), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(height: 24),
        Icon(joined ? Icons.call : Icons.call_outlined, size: 76,
          color: joined ? Colors.green : Theme.of(context).colorScheme.primary),
        const SizedBox(height: 18),
        Text(status, textAlign: TextAlign.center),
        const SizedBox(height: 24),
        TextField(controller: channelController, enabled: !joined,
          decoration: const InputDecoration(labelText: 'Channel name', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: busy ? null : (joined ? endCall : startCall),
          icon: Icon(joined ? Icons.call_end : Icons.call),
          label: Text(busy ? 'Please wait...' : (joined ? 'End Call' : 'Start Voice Call')),
        ),
        const SizedBox(height: 18),
        const Text('Both phones must join the same channel using valid RTC tokens.',
          textAlign: TextAlign.center),
      ],
    )),
  );
}
